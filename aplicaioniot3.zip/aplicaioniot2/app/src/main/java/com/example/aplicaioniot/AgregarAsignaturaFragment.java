package com.example.aplicaioniot;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

public class AgregarAsignaturaFragment extends Fragment {

    private EditText editTextName; // EditText para el nombre de la asignatura
    private EditText editTextDescription; // EditText para la descripción
    private EditText editTextNameToDelete; // EditText para el nombre de la asignatura a eliminar
    private EditText editTextRating; // EditText para el rating
    private Button buttonSave; // Botón para guardar
    private Button buttonDelete; // Botón para eliminar

    private FirebaseFirestore db;

    @SuppressLint("MissingInflatedId")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_agregar_asignatura, container, false);

        // Inicializar EditTexts y botones
        editTextName = view.findViewById(R.id.editTextName);
        editTextDescription = view.findViewById(R.id.editTextDescription);
        editTextNameToDelete = view.findViewById(R.id.editTextNameToDelete);
        editTextRating = view.findViewById(R.id.editTextRating); // Inicializar EditText para el rating
        buttonSave = view.findViewById(R.id.buttonSave);
        buttonDelete = view.findViewById(R.id.buttonDelete);

        // Inicializar Firestore
        db = FirebaseFirestore.getInstance();

        // Configurar listeners para los botones
        buttonSave.setOnClickListener(v -> saveAsignatura());
        buttonDelete.setOnClickListener(v -> deleteAsignatura());

        // Crear colección "asignaturas" si no existe
        createAsignaturasCollectionIfNotExists();

        return view;
    }

    private void saveAsignatura() {
        String name = editTextName.getText().toString().trim();
        String description = editTextDescription.getText().toString().trim();
        String ratingString = editTextRating.getText().toString().trim();

        // Validar entradas
        if (name.isEmpty() || description.isEmpty() || ratingString.isEmpty()) {
            Toast.makeText(getActivity(), "Por favor completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int rating;
        try {
            rating = Integer.parseInt(ratingString);
            if (rating < 0 || rating > 3) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException e) {
            Toast.makeText(getActivity(), "El rating debe ser un número entre 0 y 3", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear una nueva asignatura con un ID automático
        Asignatura asignatura = new Asignatura("", name, description, rating); // ID vacío porque Firestore generará uno

        // Usar 'add()' para agregar el documento
        db.collection("asignaturas").add(asignatura)
                .addOnSuccessListener(documentReference -> {
                    // Mostrar el ID generado si es necesario
                    String generatedId = documentReference.getId(); // Obtener el ID generado
                    Toast.makeText(getActivity(), "Asignatura agregada con ID: " + generatedId, Toast.LENGTH_SHORT).show();

                    // Limpiar campos después de agregar
                    clearFields();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getActivity(), "Error al agregar asignatura", Toast.LENGTH_SHORT).show();
                });
    }

    private void deleteAsignatura() {
        String nameToDelete = editTextNameToDelete.getText().toString().trim(); // Obtener el nombre del EditText

        // Validar la entrada
        if (nameToDelete.isEmpty()) {
            Toast.makeText(getActivity(), "Por favor ingresa el nombre de la asignatura a eliminar", Toast.LENGTH_SHORT).show();
            return;
        }

        // Buscar asignaturas por nombre
        db.collection("asignaturas")
                .whereEqualTo("name", nameToDelete) // Busca por nombre
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        if (task.getResult().isEmpty()) {
                            Toast.makeText(getActivity(), "No se encontró ninguna asignatura con ese nombre", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        // Eliminar cada asignatura encontrada
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            String asignaturaId = document.getId(); // Obtener el ID de la asignatura
                            // Eliminar las materias asociadas a esta asignatura
                            deleteMateriasByAsignaturaId(asignaturaId);
                            // Luego eliminar la asignatura
                            db.collection("asignaturas").document(asignaturaId).delete()
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(getActivity(), "Asignatura eliminada", Toast.LENGTH_SHORT).show();
                                        // Limpiar campos después de eliminar
                                        clearFields();
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(getActivity(), "Error al eliminar asignatura", Toast.LENGTH_SHORT).show();
                                    });
                        }
                    } else {
                        Toast.makeText(getActivity(), "Error al buscar asignaturas", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getActivity(), "Error al realizar la búsqueda", Toast.LENGTH_SHORT).show();
                });
    }

    private void deleteMateriasByAsignaturaId(String asignaturaId) {
        // Eliminar las materias asociadas a la asignatura
        db.collection("materias")
                .whereEqualTo("asignaturaId", asignaturaId) // Supone que tienes un campo "asignaturaId" en las materias
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        for (QueryDocumentSnapshot document : task.getResult()) {
                            // Eliminar cada materia encontrada
                            db.collection("materias").document(document.getId()).delete()
                                    .addOnSuccessListener(aVoid -> {
                                        // Materia eliminada exitosamente
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(getActivity(), "Error al eliminar materia: " + document.getId(), Toast.LENGTH_SHORT).show();
                                    });
                        }
                    } else {
                        Toast.makeText(getActivity(), "Error al buscar materias asociadas", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getActivity(), "Error al realizar la búsqueda de materias", Toast.LENGTH_SHORT).show();
                });
    }

    private void createAsignaturasCollectionIfNotExists() {
        db.collection("asignaturas").limit(1).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    if (queryDocumentSnapshots.isEmpty()) {
                        // Crear una nueva asignatura solo para inicializar la colección
                        Asignatura asignatura = new Asignatura("", "", "", 0); // ID vacío
                        db.collection("asignaturas").add(asignatura)
                                .addOnSuccessListener(documentReference -> {
                                    // Se ha creado la colección con un documento vacío
                                })
                                .addOnFailureListener(e -> {
                                    Toast.makeText(getActivity(), "Error al crear la colección de asignaturas", Toast.LENGTH_SHORT).show();
                                });
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getActivity(), "Error al acceder a la colección de asignaturas", Toast.LENGTH_SHORT).show();
                });
    }

    // Método para limpiar los campos
    private void clearFields() {
        editTextName.setText("");
        editTextDescription.setText("");
        editTextNameToDelete.setText("");
        editTextRating.setText(""); // Limpiar campo de rating
    }
}

